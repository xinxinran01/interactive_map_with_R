# JSON 配置
必填：project（根目录）、source（相对根目录的地图路径）、
code（地图代码字段）、name（地图名称字段）、value（数值字段）。
可选 table：相对路径 CSV，UTF-8；table_code/table_name 指定其键和名称。
没有 table 时 value 直接取地图字段。
title 默认“空间指标地图”；unit 默认空；output 默认 map。
static 默认 false。overwrite 默认 false，覆盖已有输出须本次请求支持。
layer 可指定 GPKG 图层；codes 可筛选代码列表。
breaks 为可选升序数值列表，需覆盖非缺失值全范围，labels 数量等于区间数。
缺失值允许且报告；重复键、名称冲突、关联失败均停止。
points 可为对象：source（CSV）、lon、lat、name、epsg；
已知 EPSG 数值必填；category 可按类别分色。
点缺失或非法坐标停止；GCJ-02 需单独转换，不能仅改 CRS 标签。
将变量单位和统计时段写入 title/unit；仅使用真实已提供信息。
脚本支持通用点弹窗；复杂大小映射和额外弹窗可在项目副本中扩展并测试。
运行：Rscript map.R config.json。

